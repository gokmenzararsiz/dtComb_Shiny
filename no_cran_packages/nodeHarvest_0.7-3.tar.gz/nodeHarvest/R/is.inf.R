is.inf <-
function(x) (abs(x)==Inf)

